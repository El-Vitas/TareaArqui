Integrantes
	Jonathan Nicolás Olivares Salinas, Rol 202073096-2, Paralelo 200
	Sebastian Enrique Arrieta Moron, Rol 202173511-9 , Paralelo 200
	
Para la ejecución del circuito considerar lo siguiente:
	-Existe un botón on/off, cuando es 1 está encendido, caso contrario apagado. Mientras se encuentre apagado el programa no cambia de estado.
	-Al circuito se le debe indicar las coordenadas y activar el reloj para que vaya cambiando de estado, cambia en cada pulso del reloj en la cual el reloj es 1; Es decir: 0, 1 (cambia),0, 1 (cambia).
	-Se asume que se ingresan las coordenadas correctas.
	-El circuito al llegar al final deja de considerar los pulsos del reloj y no cambia de estado.
	-El circuito cambia de estado cada vez que se le ingrese una nueva coordenada, considerando ahora esta nueva coordenada, incluso si ya llego al final, si se cambia de coordenadas entonces la considerará y se iniciará el circuito en esa coordenada.